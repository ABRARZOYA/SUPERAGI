# GreetingTool
SuperAGI Greeting Tool -  A sample tool to help create new external tools.
